import { useSelector } from 'react-redux';
import { VEHICLE_STATUS, resolveVehicleStatus } from '../common/theme/status';

// لا يُعيد هذا الـhook حساب أي شيء يوفره Traccar بالفعل — فقط يجمع (count) نتيجة
// resolveVehicleStatus (Phase 1) على كل جهاز موجود في state.devices.items، باستخدام
// state.session.positions الحية نفسها التي تستخدمها الخريطة وDeviceList.
const useDeviceStatusCounts = () => {
  const devices = useSelector((state) => state.devices.items);
  const positions = useSelector((state) => state.session.positions);
  const eventCount = useSelector((state) => state.events.items.length);

  const counts = {
    total: 0,
    [VEHICLE_STATUS.MOVING]: 0,
    [VEHICLE_STATUS.STOPPED]: 0,
    [VEHICLE_STATUS.OFFLINE]: 0,
    [VEHICLE_STATUS.UNKNOWN]: 0,
  };

  Object.values(devices).forEach((device) => {
    counts.total += 1;
    const status = resolveVehicleStatus(device, positions[device.id]);
    counts[status] += 1;
  });

  return { ...counts, alerts: eventCount };
};

export default useDeviceStatusCounts;
