import { Fragment } from 'react';
import {
  List,
  ListItemText,
  ListItemIcon,
  ListItemButton,
  ListSubheader,
  Badge,
  Tooltip,
  Box,
} from '@mui/material';
import { Link, useLocation } from 'react-router-dom';
import { makeStyles } from 'tss-react/mui';
import { useSelector } from 'react-redux';
import { useTranslation } from './LocalizationProvider';
import { buildNavGroups } from './navRoutes';
import { useRestriction } from '../util/permissions';

const useStyles = makeStyles()((theme) => ({
  subheader: {
    fontSize: '0.6875rem',
    fontWeight: 700,
    letterSpacing: '0.06em',
    textTransform: 'uppercase',
    color: theme.palette.text.disabled,
    lineHeight: '32px',
    backgroundColor: 'transparent',
  },
  itemButton: {
    borderRadius: theme.shape.borderRadius,
    marginInline: theme.spacing(1),
    marginBottom: 2,
    width: 'auto',
    '&.Mui-selected': {
      backgroundColor: theme.palette.mode === 'dark'
        ? 'rgba(255,255,255,0.08)'
        : `${theme.palette.primary.main}14`,
      '& .MuiListItemIcon-root': {
        color: theme.palette.primary.main,
      },
      '& .MuiListItemText-primary': {
        fontWeight: 700,
        color: theme.palette.primary.main,
      },
    },
  },
  icon: {
    minWidth: 40,
  },
  itemCollapsed: {
    justifyContent: 'center',
    paddingInline: theme.spacing(1),
  },
}));

// miniVariant: عرض مصغّر (أيقونات فقط + Tooltip). ملاحظة: هذا المكوّن جاهز ومستقل،
// لكن غير مربوط بعد بأي صفحة — انظر تقرير Phase 2 لسبب ذلك.
const SideNav = ({ miniVariant = false }) => {
  const { classes, cx } = useStyles();
  const location = useLocation();
  const t = useTranslation();

  const readonly = useRestriction('readonly');
  const disableReports = useRestriction('disableReports');
  const eventCount = useSelector((state) => state.events.items.length);

  const groups = buildNavGroups({ readonly, disableReports });

  const renderItem = (item) => {
    const Icon = item.icon;
    const selected = location.pathname.match(item.match || `^${item.href}`) !== null;
    const badgeCount = item.badge === 'events' ? eventCount : 0;

    const button = (
      <ListItemButton
        key={item.key}
        component={Link}
        to={item.href}
        selected={selected}
        className={cx(classes.itemButton, miniVariant && classes.itemCollapsed)}
      >
        <ListItemIcon className={classes.icon}>
          <Badge color="error" badgeContent={badgeCount} max={9} overlap="circular">
            <Icon fontSize="small" />
          </Badge>
        </ListItemIcon>
        {!miniVariant && <ListItemText primary={t(item.labelKey)} />}
      </ListItemButton>
    );

    if (miniVariant) {
      return (
        <Tooltip key={item.key} title={t(item.labelKey)} placement="right">
          <Box>{button}</Box>
        </Tooltip>
      );
    }
    return button;
  };

  return (
    <List disablePadding sx={{ paddingTop: 1 }}>
      {groups.map((group) => {
        const visibleItems = group.items.filter((item) => !item.hidden);
        if (!visibleItems.length) return null;
        return (
          <Fragment key={group.subheader}>
            {!miniVariant && (
              <ListSubheader className={classes.subheader} disableSticky>
                {t(group.subheader)}
              </ListSubheader>
            )}
            {visibleItems.map(renderItem)}
          </Fragment>
        );
      })}
    </List>
  );
};

export default SideNav;
