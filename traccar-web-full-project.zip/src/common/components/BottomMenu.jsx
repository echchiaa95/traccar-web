import { useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import {
  Paper,
  BottomNavigation,
  BottomNavigationAction,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Badge,
  Divider,
  Box,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';

import MoreHorizRoundedIcon from '@mui/icons-material/MoreHorizRounded';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import PersonIcon from '@mui/icons-material/Person';

import { useTranslation } from './LocalizationProvider';
import { useRestriction } from '../util/permissions';
import { buildNavGroups, MOBILE_PRIMARY_KEYS } from './navRoutes';
import useLogout from '../util/useLogout';

const useStyles = makeStyles()((theme) => ({
  root: {
    // دعم iPhone safe area — لا يغطي Bottom Navigation عناصر النظام
    paddingBottom: 'env(safe-area-inset-bottom)',
  },
  action: {
    minWidth: 'auto',
  },
  moreList: {
    width: 260,
  },
}));

const BottomMenu = () => {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const location = useLocation();
  const t = useTranslation();
  const logout = useLogout();

  const readonly = useRestriction('readonly');
  const disableReports = useRestriction('disableReports');
  const user = useSelector((state) => state.session.user);
  const socket = useSelector((state) => state.session.socket);
  const eventCount = useSelector((state) => state.events.items.length);

  const [moreOpen, setMoreOpen] = useState(false);

  const groups = buildNavGroups({ readonly, disableReports });
  const allItems = groups.flatMap((group) => group.items).filter((item) => !item.hidden);
  const primaryItems = MOBILE_PRIMARY_KEYS.map((key) => allItems.find((item) => item.key === key)).filter(Boolean);
  const moreItems = allItems.filter((item) => !MOBILE_PRIMARY_KEYS.includes(item.key));

  const currentSelection = () => {
    const match = primaryItems.find((item) => location.pathname.match(item.match || `^${item.href}`));
    if (match) return match.key;
    if (location.pathname.startsWith('/settings') || location.pathname.startsWith('/reports') || location.pathname === '/replay' || location.pathname === '/geofences') {
      return 'more';
    }
    return null;
  };

  const handleSelection = (event, value) => {
    if (value === 'more') {
      setMoreOpen(true);
      return;
    }
    const item = primaryItems.find((it) => it.key === value);
    if (item) navigate(item.href);
  };

  return (
    <Paper square elevation={3} className={classes.root}>
      <BottomNavigation value={currentSelection()} onChange={handleSelection} showLabels>
        {primaryItems.map((item) => {
          const Icon = item.icon;
          const badgeCount = item.badge === 'events' ? eventCount : 0;
          return (
            <BottomNavigationAction
              key={item.key}
              className={classes.action}
              label={t(item.labelKey)}
              value={item.key}
              icon={
                item.key === 'dashboard' ? (
                  <Badge color="error" variant="dot" overlap="circular" invisible={socket !== false}>
                    <Icon />
                  </Badge>
                ) : (
                  <Badge color="error" badgeContent={badgeCount} max={9} overlap="circular">
                    <Icon />
                  </Badge>
                )
              }
            />
          );
        })}
        <BottomNavigationAction className={classes.action} label={t('sharedMore')} value="more" icon={<MoreHorizRoundedIcon />} />
      </BottomNavigation>

      <Drawer anchor="bottom" open={moreOpen} onClose={() => setMoreOpen(false)}>
        <Box className={classes.moreList} role="presentation" onClick={() => setMoreOpen(false)}>
          <List>
            {moreItems.map((item) => {
              const Icon = item.icon;
              return (
                <ListItemButton key={item.key} component={Link} to={item.href}>
                  <ListItemIcon><Icon /></ListItemIcon>
                  <ListItemText primary={t(item.labelKey)} />
                </ListItemButton>
              );
            })}
            <Divider />
            {!readonly && (
              <ListItemButton component={Link} to={`/settings/user/${user.id}`}>
                <ListItemIcon><PersonIcon /></ListItemIcon>
                <ListItemText primary={t('settingsUser')} />
              </ListItemButton>
            )}
            <ListItemButton onClick={logout}>
              <ListItemIcon><ExitToAppIcon /></ListItemIcon>
              <ListItemText primary={t('loginLogout')} />
            </ListItemButton>
          </List>
        </Box>
      </Drawer>
    </Paper>
  );
};

export default BottomMenu;
