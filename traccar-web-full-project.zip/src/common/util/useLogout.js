import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { sessionActions } from '../../store';
import { nativePostMessage } from '../components/NativeInterface';

// نفس منطق handleLogout الموجود سابقًا داخل BottomMenu.jsx حرفيًا — تم فقط نقله
// إلى hook مشترك حتى لا يتكرر داخل NavBar.jsx الجديد. لا تغيير في السلوك.
const useLogout = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const user = useSelector((state) => state.session.user);

  return async () => {
    const notificationToken = window.localStorage.getItem('notificationToken');
    if (notificationToken && user && !user.readonly) {
      window.localStorage.removeItem('notificationToken');
      const tokens = user.attributes.notificationTokens?.split(',') || [];
      if (tokens.includes(notificationToken)) {
        const updatedUser = {
          ...user,
          attributes: {
            ...user.attributes,
            notificationTokens:
              tokens.length > 1
                ? tokens.filter((it) => it !== notificationToken).join(',')
                : undefined,
          },
        };
        await fetch(`/api/users/${user.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updatedUser),
        });
      }
    }

    await fetch('/api/session', { method: 'DELETE' });
    nativePostMessage('logout');
    navigate('/login');
    dispatch(sessionActions.updateUser(null));
  };
};

export default useLogout;
